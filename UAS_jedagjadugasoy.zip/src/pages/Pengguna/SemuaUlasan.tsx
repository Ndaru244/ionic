import { getDocs, collection, getFirestore } from "@firebase/firestore";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonThumbnail,
  IonCol,
  IonGrid,
  IonRow,
  IonItem,
  IonImg,
  IonLabel,
  IonAvatar,
  IonIcon,
  IonButtons,
  IonCardSubtitle,
} from "@ionic/react";
import { cartOutline } from "ionicons/icons";
import React, { useEffect, useState } from "react";
import firebaseConfig from "../../firebaseConfig";

const SemuaUlasan: React.FC = () => {
  const [ulasan, setUlasan] = useState<Array<any>>([]);
  const db = getFirestore(firebaseConfig);
  useEffect(() => {
    async function getData() {
      const querysnapshotUtama = await getDocs(collection(db, "ulasan"));
      console.log("QuerySnaphoot ", querysnapshotUtama);
      setUlasan(
        querysnapshotUtama.docs.map((doc) => ({ ...doc.data(), id: doc.id }))
      );
      querysnapshotUtama.forEach((doc) => {
        console.log(`${doc.id}=>${doc.data()}`);
        console.log("docs:", doc);
      });
    }
    getData();
  }, []);
  return (
    <IonPage>
      <IonHeader className="mb-5px">
        <IonToolbar color="danger">
          <IonTitle slot="start" className="Title">
            Semua Ulasan
          </IonTitle>
          <IonButtons slot="end">
            <IonItem color="none" href="/keranjang">
              <IonIcon icon={cartOutline} slot=""></IonIcon>
            </IonItem>
            <IonItem color="none">
              <IonAvatar className="image-size profile" slot="">
                <img src="assets/images/unggul.jpg" alt="Profile" />
              </IonAvatar>
            </IonItem>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        {ulasan.map((ulasanPelanggan) => (
          <><IonItem key={ulasanPelanggan.id} lines="none">
                <IonThumbnail className="img-thumbnail margin">
                    <IonImg src={ulasanPelanggan.fotoURL}></IonImg>
                </IonThumbnail>
                <IonLabel className="ml-30px" >
                    <IonLabel className="bold">{ulasanPelanggan.nama}</IonLabel>
                    <IonCardSubtitle>{ulasanPelanggan.ulasan}</IonCardSubtitle>
                </IonLabel>
            </IonItem><hr /></>
        ))}
      </IonContent>
    </IonPage>
  );
};

export default SemuaUlasan;
