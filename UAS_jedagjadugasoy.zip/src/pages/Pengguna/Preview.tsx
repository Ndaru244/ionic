import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonTitle,
  IonContent,
  IonCard,
  IonLabel,
  IonCol,
  IonGrid,
  IonRow,
  IonButton,
  IonFab,
  IonIcon,
  IonToast,
  IonAlert,
  IonFooter,
  IonCardHeader,
  IonCardTitle,
  IonChip,
  IonCardContent,
} from "@ionic/react";
import React, { useContext, useRef, useState } from "react";
import { useParams } from "react-router";
import { cartOutline, text } from "ionicons/icons";
import PesananContext from "../../components/pesananContext";

const Preview: React.FC = () => {
  const id = useParams<{ id: string }>().id;
  const nama = useParams<{ nama: string }>().nama;
  const harga = useParams<{ harga: string }>().harga;
  const foto = useParams<{ foto: string }>().foto;
  const fotoURL = useParams<{ url: string }>().url;
  const deskripsi = useParams<{ deskripsi: string }>().deskripsi;
  const jenis = useParams<{ jenis: string }>().jenis;

  const [masukKeranjang, setMasukKeranjang] = useState(false);
  const pesananCTX = useContext(PesananContext);

  const openToast = () => {
    setMasukKeranjang(true);
  };

  const cek = () => {
    console.log(pesananCTX.pesanan.length);
    console.log(pesananCTX.pesanan);
  };

  return (
    <IonPage>
      <IonAlert
        mode="ios"
        isOpen={!!masukKeranjang}
        header="Masukkan Keranjang"
        inputs={[
          {
            name: "banyak",
            type: "number",
            placeholder: "Masukkan banyaknya pesanan",
          },
          { name: "pesan", type: "text", placeholder: "Pesan" },
        ]}
        buttons={[
          { text: "Cancel", handler: () => setMasukKeranjang(false) },
          {
            text: "Tambahkan",
            handler: (res) => {
              pesananCTX.addKeranjang(
                id,
                nama,
                foto,
                fotoURL,
                parseInt(harga),
                res.banyak,
                res.pesan
              );
              setMasukKeranjang(false);
            },
          },
        ]}
      />
      <IonHeader>
        <IonToolbar color="danger">
          <IonButtons>
            <IonBackButton
              className="Title"
              defaultHref={`/daftar/${jenis}`}
            ></IonBackButton>
            <IonTitle className="Title">{nama}</IonTitle>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent>
        <img
          className="foto-preview"
          src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${foto}?${fotoURL}`}
          alt={nama}
        />
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>
              <IonRow>
                <IonCol size="8">
                  <h3 className="bold">{nama}</h3>
                </IonCol>
                <IonCol size="4">
                  <IonChip color="primary">
                    <IonLabel>
                      <h3 className="bold">RP.{harga}</h3>
                    </IonLabel>
                  </IonChip>
                </IonCol>
              </IonRow>
            </IonCardTitle>
          </IonCardHeader>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle className="bold">Deskripsi</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            <IonLabel>{deskripsi}</IonLabel>
          </IonCardContent>
        </IonCard>

      </IonContent>
      <IonFooter mode="md">
        <IonGrid>
          <IonRow>
            <IonCol className="ion-text-center">
              <IonButton onClick={openToast} color="danger">
                <IonIcon icon={cartOutline}></IonIcon>
                Masukkan Keranjang
              </IonButton>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonFooter>
    </IonPage>
  );
};

export default Preview;
