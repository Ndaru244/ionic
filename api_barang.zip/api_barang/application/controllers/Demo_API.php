<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';
use chriskacerguis\RestServer\RestController;
class Demo_API extends RestController {

    public function index_get()
    {
        echo "<h1>Belajar API</h1>";
    }

}

/* End of file Demo_API.php */


?>