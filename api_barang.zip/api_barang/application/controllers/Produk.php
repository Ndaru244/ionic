<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';
use chriskacerguis\RestServer\RestController;
class Produk extends RestController {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model');
    }

    public function index_get()
    {
        $produk = new Model;
        $result = $produk->get_();
        $this->response($result, 200);
    }

    public function store_post()
    {
        $produk = new Model;
        $data = [
            'nama_produk'   =>  $this->input->post('nama_produk'),
            'tipe_produk'   =>  $this->input->post('tipe_produk'),
            'harga'         =>  $this->input->post('harga'),
            'stok'          =>  $this->input->post('stok')
        ];
        $result = $produk->insert_($data);
        if($result > 0) {
            $this->response([
                'status'  => true,
                'message' => 'NEW PRODUK CREATED'
                ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status'  => false,
                'message' => 'FAILED TO CREATE NEW PRODUK'
            ], RestController::HTTP_BAD_REQUEST);
        }
    }

    public function edit_get($id)
    {
        $produk = new Model;
        $produk = $produk->edit_($id);
        $this->response($produk, 200);
    }

    public function update_put($id)
    {
        $produk = new Model;
        $data = [
            'nama_produk'   =>  $this->put('nama_produk'),
            'tipe_produk'   =>  $this->put('tipe_produk'),
            'harga'         =>  $this->put('harga'),
            'stok'          =>  $this->put('stok')
        ];

        $result = $produk->update_($data, $id);
        if($result > 0) {
            $this->response([
                'status' => true,
                'message' => 'PRODUK UPDATED'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'FAILED TO UPDATE PRODUK'
            ], RestController::HTTP_BAD_REQUEST);
        }
    }

    public function delete_delete($id)
    {
        $produk = new Model;
        $result = $produk->delete_($id);

        if($result > 0) {
            $this->response([
                'status' => true,
                'message' => 'PRODUK DELETED'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'FAILED TO DELETE PRODUK'
            ], RestController::HTTP_BAD_REQUEST);
        }
    }

}

/* End of file Produk.php */


?>