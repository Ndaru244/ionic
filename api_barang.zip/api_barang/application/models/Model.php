<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Model {

    public function get_()
    {
        $query = $this->db->get("produk");
        return $query->result();
    }
    public function insert_($data)
    {
        return $this->db->insert('produk', $data);
    }
    public function edit_($id)
    {
        $this->db->where('id',$id);
        $query = $this->db->get('produk');
        return $query->row();
    }
    public function update_($data, $id)
    {
        $this->db->where(['id' => $id]);
        return $this->db->update('produk', $data);
    }
    public function delete_($id)
    {
        return $this->db->delete('produk', ['id' => $id]);
    }

}

/* End of file Model.php */
 ?>