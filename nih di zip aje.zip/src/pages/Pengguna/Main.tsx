import { IonPage, IonHeader, IonToolbar, IonLabel, IonIcon, IonAvatar, IonTitle, IonCol, IonGrid, IonRow, IonContent, IonCard, IonSlide, IonSlides, IonButton, IonItem } from "@ionic/react";
import React from "react";
import { cartOutline, star } from 'ionicons/icons'
import './pengguna.css'
import firebaseConfig from '../../firebaseConfig'
import { getFirestore, getDocs, collection, doc } from 'firebase/firestore';
import { useState, useEffect } from "react";

const Main: React.FC = () => {
    const db = getFirestore(firebaseConfig);
    const [daftarMakanan, setDaftarMakanan] = useState<Array<any>>([]);
    useEffect(() => {
        async function getData() {
            const querysnapshot = await getDocs(collection(db, "daftar-makanan"));
            console.log('QuerySnaphoot ', querysnapshot);
            setDaftarMakanan(querysnapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id })));

            querysnapshot.forEach((doc) => {
                console.log(`${doc.id}=>${doc.data()}`);
                console.log('docs:', doc);
            });
        }
        getData();

    }, []);
    return (
        <IonPage>
            <IonHeader className="mb-20px">
                <IonToolbar color="danger">
                    <IonRow>
                        <IonCol className="">
                            <IonTitle className="Title">Resto Osteria</IonTitle>
                        </IonCol>
                        <IonCol className="ml-43percent">
                            <IonItem className="width-cart" color="danger" button href="/keranjang">
                                <IonIcon className="Title" icon={cartOutline} slot=""></IonIcon>
                            </IonItem>
                        </IonCol>
                        <IonCol>
                            <IonAvatar className="image-size profile" slot="">
                                <img src="assets/images/unggul.jpg" alt="Profile" />
                            </IonAvatar>
                        </IonCol>
                    </IonRow>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonLabel className="ml-30px sub-header">Kategori Menu</IonLabel>
                <IonCard color="danger">
                    <IonGrid>
                        <IonRow>
                            <IonCol>
                                <IonCard button href="/pilihjenismakanan">
                                    <img src='https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/Nasi%20Goreng.jpeg?alt=media&token=b2f3e409-59b2-4bd6-9843-c1ad2b8d98c4' alt="masa" />
                                    <h6 className="ion-text-center black margin-top0 bold">Makanan</h6>
                                </IonCard>
                            </IonCol>
                            <IonCol>
                                <IonCard button href="/daftar/minuman">
                                    <img src="assets/images/JUS.jpg" alt="" />
                                    <h6 className="ion-text-center black margin-top0 bold">Minuman</h6>
                                </IonCard>
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                </IonCard><br />
                <IonLabel className="ml-30px sub-header">Top 5 Food in Resto Osteria</IonLabel>
                <IonSlides className="">
                    <IonSlide className="width-slide ml-30px">
                        <div>
                            <IonCard button href="#" className="ioncard-setting-slide">
                                <img className="fix-ioncard-images" src="assets/images/Nasi-Goreng.jpeg" alt="Top1" />
                            </IonCard>
                            <IonGrid>
                                <IonRow>
                                    <IonCol>
                                        <IonLabel>Nasi Goreng</IonLabel>
                                    </IonCol>
                                    <IonCol>
                                        <IonLabel>
                                            <IonIcon icon={star}></IonIcon>
                                            4.8
                                        </IonLabel>
                                    </IonCol>
                                </IonRow>
                            </IonGrid>
                        </div>
                    </IonSlide>
                </IonSlides><br /><br />
                <IonLabel className="ml-30px sub-header">Top 5 Drinks in Resto Osteria</IonLabel>
                <IonSlides className="">
                    <IonSlide className="width-slide ml-30px">
                        <div>
                            <IonCard button href="#" className="ioncard-setting-slide">
                                <img className="fix-ioncard-images" src="assets/images/JUS.jpg" alt="Top1" />
                            </IonCard>
                            <IonGrid>
                                <IonRow>
                                    <IonCol>
                                        <IonLabel>Nasi Goreng</IonLabel>
                                    </IonCol>
                                    <IonCol>
                                        <IonLabel>
                                            <IonIcon icon={star}></IonIcon>
                                            4.8
                                        </IonLabel>
                                    </IonCol>
                                </IonRow>
                            </IonGrid>
                        </div>
                    </IonSlide>
                </IonSlides>
            </IonContent>
        </IonPage >
    )
}

export default Main;
