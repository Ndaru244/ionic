import { getDocs, collection, getFirestore } from "@firebase/firestore";
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonThumbnail, IonCol, IonGrid, IonRow, IonItem, IonImg, IonLabel, IonAvatar, IonIcon } from "@ionic/react";
import { cartOutline } from "ionicons/icons";
import React, { useEffect, useState } from "react";
import firebaseConfig from '../../firebaseConfig';

const SemuaUlasan: React.FC = () => {
    const [ulasan, setUlasan] = useState<Array<any>>([]);
    const db = getFirestore(firebaseConfig);
    useEffect(() => {
        async function getData() {
            const querysnapshotUtama = await getDocs(collection(db, "ulasan"));
            console.log('QuerySnaphoot ', querysnapshotUtama);
            setUlasan(querysnapshotUtama.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
            querysnapshotUtama.forEach((doc) => {
                console.log(`${doc.id}=>${doc.data()}`);
                console.log('docs:', doc);
            });
        }
        getData();

    }, []);
    return (
        <IonPage>
            <IonHeader className="mb-5px">
                <IonToolbar color="danger">
                    <IonGrid>
                        <IonRow>
                            <IonCol className="width-title">
                                <IonTitle className="Title">Semua Ulasan</IonTitle>
                            </IonCol>
                            <IonCol className="ml-70percent">
                                <IonItem color="danger" button href="/keranjang">
                                    <IonIcon className="Title" icon={cartOutline} slot=""></IonIcon>
                                </IonItem>
                            </IonCol>
                            <IonCol>
                                <IonAvatar className="image-size profile" slot="">
                                    <img src="assets/images/unggul.jpg" alt="Profile" />
                                </IonAvatar>
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                {ulasan.map(ulasanPelanggan => (
                    <IonItem key={ulasanPelanggan.id}>
                        <IonThumbnail className="img-thumbnail margin0">
                            <IonImg src={ulasanPelanggan.fotoURL}></IonImg>
                        </IonThumbnail>
                        <IonLabel className="ml-30px">
                            <h1 className="bold">{ulasanPelanggan.nama}</h1>
                            <h6>{ulasanPelanggan.ulasan}</h6>
                        </IonLabel>
                    </IonItem>
                ))}
            </IonContent>
        </IonPage>
    )
}

export default SemuaUlasan;