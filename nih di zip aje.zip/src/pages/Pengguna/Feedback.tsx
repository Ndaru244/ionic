import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonInput, IonItem, IonLabel, IonButton, IonCol, IonGrid, IonIcon, IonRow, IonAvatar } from "@ionic/react";
import React, { useRef, useState } from "react";
import { camera, cartOutline } from 'ionicons/icons';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { base64FromPath } from "@ionic/react-hooks/filesystem";
import { uploadBytes, getStorage, ref, getDownloadURL } from 'firebase/storage';
import { collection, addDoc, getFirestore } from "@firebase/firestore";
import firebaseConfig from '../../firebaseConfig';

const Feedback: React.FC = () => {
    const nama = useRef<HTMLIonInputElement>(null);
    const ulasan = useRef<HTMLIonInputElement>(null);
    const telp = useRef<HTMLIonInputElement>(null);
    const [takenPhoto, setTakenPhotos] = useState<{
        path: string | undefined;
        preview: string
    }>();
    const storage = getStorage();
    const db = getFirestore(firebaseConfig);

    const takePhotoHandler = async () => {
        const image = await Camera.getPhoto({
            resultType: CameraResultType.Uri,
            source: CameraSource.Camera,
            quality: 80,
            width: 500
        });
        console.log(image);
        if (!image || /*!image.path ||*/ !image.webPath) {
            return;
        }
        setTakenPhotos({
            path: image.path,
            preview: image.webPath
        })
    }

    const addMemory = async () => {
        const enteredNama = nama.current?.value;
        const enteredUlasan = ulasan.current?.value;
        const enteredTelp = telp.current?.value;
        if (!enteredNama || enteredNama.toString().trim().length === 0 || !enteredUlasan || enteredUlasan.toString().trim().length === 0 || !enteredTelp || enteredTelp.toString().trim().length === 0 || !takenPhoto) {
            return console.log("wkwk");
        }
        const fileName = new Date().getTime() + '.jpeg';
        const base64Data = await takenPhoto!.preview;
        const storageRef = ref(storage, fileName);
        fetch(base64Data)
            .then(async (res) => {
                const parseBlob = await res.blob();
                uploadBytes(storageRef, parseBlob).then((snapshoot) => {
                    console.log('upload file success');
                    getDownloadURL(ref(storage, fileName)).then((url) => {
                        const addData = async () => {
                            try {
                                const docRef = await addDoc(collection(db, "ulasan"), {
                                    nama: enteredNama.toString(),
                                    ulasan: enteredUlasan.toString(),
                                    telp: enteredTelp.toString(),
                                    foto: fileName,
                                    fotoURL: url
                                })
                                console.log("Document written with ID: ", docRef.id);
                                window.location.href = "/home";
                            } catch (e) {
                                console.error("Error adding document : ", e);
                            }
                        }
                        addData();
                    })
                })
            })
    }
    return (
        <IonPage>
            <IonHeader>
                <IonToolbar color="danger">
                    <IonGrid>
                        <IonRow>
                            <IonCol>
                                <IonTitle className="Title">Tulis Ulasan</IonTitle>
                            </IonCol>
                            <IonCol className="ml-70percent">
                                <IonItem color="danger" button href="/keranjang">
                                    <IonIcon className="Title" icon={cartOutline} slot=""></IonIcon>
                                </IonItem>
                            </IonCol>
                            <IonCol>
                                <IonAvatar className="image-size profile" slot="">
                                    <img src="assets/images/unggul.jpg" alt="Profile" />
                                </IonAvatar>
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonItem>
                    <IonLabel position="floating">Nama Pelanggan</IonLabel>
                    <IonInput ref={nama}></IonInput>
                </IonItem>
                <IonItem>
                    <IonLabel position="floating">No Telp</IonLabel>
                    <IonInput ref={telp}></IonInput>
                </IonItem>
                <IonItem>
                    <IonLabel position="floating">Feedback</IonLabel>
                    <IonInput ref={ulasan}></IonInput>
                </IonItem>
                <IonGrid>
                    <IonRow className="ion-text-center">
                        <IonCol>
                            <div className="bingkai-foto">
                                {!takenPhoto && <h3>No photo choosen</h3>}
                                {takenPhoto && <img src={takenPhoto.preview} alt="preview" />}
                            </div>
                            <IonButton fill="clear" onClick={takePhotoHandler}>
                                <IonIcon color="success" slot="start" icon={camera}></IonIcon>
                                <IonLabel color="success">Take Photo</IonLabel>
                            </IonButton>
                        </IonCol>
                    </IonRow>
                    <IonRow className="ion-margin-top">
                        <IonCol className="ion-text-center">
                            <IonButton onClick={addMemory}>Add Memory</IonButton>
                        </IonCol>
                    </IonRow>
                </IonGrid>
            </IonContent>
        </IonPage>
    )
}

export default Feedback;


