import { IonItem, IonThumbnail, IonImg, IonLabel, IonAvatar, IonCol, IonContent, IonGrid, IonHeader, IonIcon, IonPage, IonRow, IonTitle, IonToolbar, IonBackButton, IonButtons, IonButton, IonItemSliding, IonItemOption, IonItemOptions, IonAlert, IonModal } from "@ionic/react";
import { addDoc, collection, getFirestore } from "firebase/firestore";
import { cartOutline, createOutline, trashBinOutline, trashOutline } from "ionicons/icons";
import React, { useContext, useState } from "react";
import PesananContext from "../../components/pesananContext";
import firebaseConfig from "../../firebaseConfig";
import { connect } from "react-redux";

const Keranjang: React.FC = () => {
    const pesananCTX = useContext(PesananContext);
    const db = getFirestore(firebaseConfig);
    const [openDelete, setOpenDelete] = useState(false);
    const [idDelete, setIdDelete] = useState('');
    const [openEdit, setOpenEdit] = useState(false);

    const addData = async () => {
        try {
            const docRef = await addDoc(collection(db, "pesanan"), {
                id: pesananCTX.pesanan.map(menu => (menu.id)),
                menu: pesananCTX.pesanan.map(menu => (menu.nama)),
                foto: pesananCTX.pesanan.map(menu => (menu.foto)),
                fotoURL: pesananCTX.pesanan.map(menu => (menu.fotoURL)),
                harga: pesananCTX.pesanan.map(menu => (menu.harga * menu.jumlah)),
                jumlah: pesananCTX.pesanan.map(menu => (menu.jumlah)),
                pesan: pesananCTX.pesanan.map(menu => (menu.pesan))
            })
            console.log("Document written with ID: ", docRef.id);
            pesananCTX.deleteKeranjang()
            window.location.href = "/home";
        } catch (e) {
            console.error("Error adding document : ", e);
        }
    }

    const openAlertDelete = (id: String) =>{
        const idMenu = pesananCTX.pesanan.find(f => f.id === id);
        if(!idMenu) return;
        setIdDelete(idMenu?.id);
        setOpenDelete(true);
    }

    const deleteSatuanData = () =>{
        pesananCTX.deleteSatuan(idDelete);
        setOpenDelete(false)
    }
    return (
        <IonPage>
             <IonAlert isOpen={!!openDelete}
                     header="Confirm Action Delete"
                     message="Yakin ingin menghapus data dari daftar jodoh?"
                     buttons={[
                         { text: "Cancel", handler: () => setOpenDelete(false) },
                         { text: "Yakin", handler: () => deleteSatuanData() }
                     ]}
                 />
                 
            <IonHeader>
                <IonToolbar color="danger">
                    <IonGrid>
                        <IonRow>
                            <IonCol>
                                <IonButtons>
                                    <IonBackButton defaultHref="/home"></IonBackButton>
                                    <IonTitle className="Title">Keranjang</IonTitle>
                                </IonButtons>
                            </IonCol>
                            <IonCol className="ml-70percent">
                                <IonItem color="danger" button href="/keranjang">
                                    <IonIcon className="Title" icon={cartOutline} slot=""></IonIcon>
                                </IonItem>
                            </IonCol>
                            <IonCol>
                                <IonAvatar className="image-size profile" slot="">
                                    <img src="assets/images/unggul.jpg" alt="Profile" />
                                </IonAvatar>
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                {pesananCTX.pesanan.length === 0 ? <>
                    <IonGrid>
                        <IonRow>
                            <IonCol className="ion-text-center">
                                <IonLabel>Belum ada pesanan</IonLabel>
                            </IonCol>
                        </IonRow>
                        <IonRow>
                            <IonCol className="ion-text-center">
                                <IonButton href="/home">
                                    Pesan Sekarang
                                </IonButton>
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                </> : <>
                    {pesananCTX.pesanan.map(pesanan =>
                        <IonItemSliding>
                            <IonItemOptions side="start">
                                <IonItemOption color="warning">
                                    <IonIcon slot="icon-only" icon={createOutline}></IonIcon>
                                </IonItemOption>
                            </IonItemOptions>
                            <IonItemOptions side="end">
                                <IonItemOption  onClick={openAlertDelete.bind(null, pesanan.id)} color="danger">
                                    <IonIcon slot="icon-only" icon={trashOutline}></IonIcon>
                                </IonItemOption>
                            </IonItemOptions>
                            <IonItem key={pesanan.id}>
                            <IonThumbnail>
                                <IonImg src={`https://firebasestorage.googleapis.com/v0/b/uas-umn.appspot.com/o/${pesanan.foto}?${pesanan.fotoURL}`}></IonImg>
                            </IonThumbnail>
                            <IonLabel className="ion-padding">
                                <h1 className="bold">{pesanan.nama}</h1>
                                <h6>QTY : {pesanan.jumlah}</h6>
                                <h6>Harga : {pesanan.harga * pesanan.jumlah}</h6>
                                <h6>Pesan : {pesanan.pesan}</h6>
                            </IonLabel>
                        </IonItem>
                        </IonItemSliding>
                    )}
                    <br />
                    <IonGrid>
                        <IonRow>
                            <IonCol className="ion-text-center">
                                <IonButton color="danger" onClick={addData}>Pesan Sekarang</IonButton>
                            </IonCol>
                        </IonRow>
                        <IonRow>
                            <IonCol className="ion-text-center">
                                <IonButton color="medium">Kembali</IonButton>
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                </>}
            </IonContent>
        </IonPage>
    )
}

export default Keranjang;