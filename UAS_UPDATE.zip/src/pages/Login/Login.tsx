import {
  IonButton,
  IonCol,
  IonContent,
  IonItem,
  IonPage,
  IonRow,
} from "@ionic/react";
import { useEffect, useState } from "react";
import "./Home.css";
import { ToastContainer } from "react-toastify";
import firebaseConfig from '../../firebaseConfig';
import { toast } from "react-toastify";
import { Bounce } from 'react-toastify';
import Main from "../Pengguna/Main";

const Login: React.FC<{ wkkw: boolean, user: any }> = props => {
  const [isLogined, setIisLogined] = useState(props.wkkw);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(props.user);

  useEffect(() => {
    firebaseConfig.auth().onAuthStateChanged(user => {
      if (user) {
        setIisLogined(true);
        return setUser(user);
      }
    });
  }, [isLogined, user]);

  const loginUser = ({ email, password }: any) => {
    firebaseConfig.auth()
      .signInWithEmailAndPassword(email, password)
      .then((res) => {
        setUser(res);
        return toast.success("Login Success!", { theme: "colored", transition: Bounce });
      })
      .catch((err) => {
        if (err.code === "auth/wrong-password") {
          return toast.error("Email or password is invalid!", { theme: "colored", transition: Bounce })
        } else if (err.code === "auth/user-not-found") {
          return toast.error("Email or password is invalid!", { theme: "colored", transition: Bounce })
        } else {
          return toast.error("Somthing went wrong!", { theme: "colored", transition: Bounce })
        }
      });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (!email || !password) {
      return toast.error("Please fill in all fields!", { theme: "colored", transition: Bounce });
    }
    const data = {
      email,
      password
    };
    loginUser(data);
  };

  const logoutUser = () => {
    firebaseConfig.auth().signOut().then((res) => {
      setIisLogined(false);
      setUser(false);
      return toast.success("Logout seccess", { theme: "colored", transition: Bounce });
    }).catch((err) => {
      return toast.error(err.message, { theme: "colored", transition: Bounce });
    })
  }

  return (

    <IonPage>
      <ToastContainer />
      <IonContent className="ion-text-center">
        {isLogined ? (
          window.location.href = "/tabs"
        ) : (
          <>
            <form onSubmit={handleSubmit}>
              <IonRow>
                <IonCol>
                  <h1 className="text-primary text-center py-5 display-4">Login</h1>
                </IonCol>
              </IonRow>

              <IonRow>
                <IonCol className="form-group">
                  <IonItem lines="none">
                    <input
                      type="email"
                      placeholder="Email"
                      name="email"
                      className="form-control"
                      value={email}
                      onChange={(e: any) => setEmail(e.target.value)}
                    />
                  </IonItem>
                </IonCol>
              </IonRow>

              <IonRow>
                <IonCol>
                  <IonItem lines="none">
                    <input
                      type="password"
                      placeholder="Password"
                      name="password"
                      className="form-control"
                      value={password}
                      onChange={(e: any) => setPassword(e.target.value)}
                    />
                  </IonItem>
                </IonCol>
              </IonRow>

              <IonRow>
                <IonCol>
                  <p style={{ fontSize: "small" }}>
                    By clicking LOGIN you agree to our <a href="#">Policy</a>
                  </p>
                  <IonButton type="submit" expand="block">
                    Login
                  </IonButton>
                  <p style={{ fontSize: "medium" }}>
                    Don't have an account? <a href="/register">Sign up!</a>
                  </p>
                </IonCol>
              </IonRow>
            </form>
          </>
        )}
      </IonContent>
    </IonPage>
  );
}
export default Login;
