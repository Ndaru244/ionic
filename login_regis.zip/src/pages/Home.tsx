import {
  IonButton,
  IonCol,
  IonContent,
  IonHeader,
  IonIcon,
  IonInput,
  IonItem,
  IonItemDivider,
  IonLabel,
  IonPage,
  IonRow,
  IonText,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { useEffect, useState } from "react";
import "./Home.css";
import { ToastContainer } from "react-toastify";
import fire from "../config/api";
import { toast } from "react-toastify";
import { Slide, Zoom, Flip, Bounce } from 'react-toastify';

const Home: React.FC = () => {
  const [ isLogined, setIisLogined ] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState({});
  
  useEffect(()=>{
    fire.auth().onAuthStateChanged(user=>{
      if (user) {
        setIisLogined(true);
        return setUser(user);
      }
    });
  },[isLogined, user]);

  const loginUser = ({email, password}:any) => {
    fire.auth()
    .signInWithEmailAndPassword(email,password)
    .then((res) => {
      setUser(res);
      return toast.success("Login Success!",{theme: "colored", transition: Bounce});
    })
    .catch((err) => {
      if (err.code === "auth/wrong-password") {
        return toast.error("Email or password is invalid!",{theme: "colored", transition: Bounce})
      } else if (err.code === "auth/user-not-found") {
        return toast.error("Email or password is invalid!",{theme: "colored", transition: Bounce})
      } else {
        return toast.error("Somthing went wrong!",{theme: "colored", transition: Bounce})
      }
    });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    if (!email || !password) {
      return toast.error("Please fill in all fields!",{theme: "colored", transition: Bounce});
    }
    const data = {
      email,
      password
    };
    loginUser(data);
  };

  const logoutUser = () => {
    fire.auth().signOut().then((res) => {
      setIisLogined(false);
      setUser(false);
      return toast.success("Logout seccess",{theme: "colored", transition: Bounce});
    }).catch((err) => {
      return toast.error(err.message,{theme: "colored", transition: Bounce});
    })
  }

  return (
    <IonPage>
      <ToastContainer/>
      <IonContent className="ion-text-center">
        {isLogined ? (
          <IonRow>
            <h1>Welcome</h1>
            <IonButton type="button" onClick={logoutUser}>logout</IonButton>
          </IonRow>
        ) : (
          <>
      <form onSubmit={handleSubmit}>
        <IonRow>
          <IonCol>
            <h1 className="text-primary text-center py-5 display-4">Login</h1>
          </IonCol>
        </IonRow>

        <IonRow>
          <IonCol className="form-group">
            <IonItem lines="none">
              <input
                type="email"
                placeholder="Email"
                name="email"
                className="form-control"
                value={email}
                onChange={(e: any) => setEmail(e.target.value)}
              />
            </IonItem>
          </IonCol>
        </IonRow>

        <IonRow>
          <IonCol>
            <IonItem lines="none">
              <input
                type="password"
                placeholder="Password"
                name="password"
                className="form-control"
                value={password}
                onChange={(e: any) => setPassword(e.target.value)}
              />
            </IonItem>
          </IonCol>
        </IonRow>

        <IonRow>
          <IonCol>
            <p style={{ fontSize: "small" }}>
              By clicking LOGIN you agree to our <a href="#">Policy</a>
            </p>
            <IonButton type="submit" expand="block">
              Login
            </IonButton>
            <p style={{ fontSize: "medium" }}>
              Don't have an account? <a href="/register">Sign up!</a>
            </p>
          </IonCol>
        </IonRow>
      </form>
    </>
        )}
      </IonContent>
    </IonPage>
  );
}

export default Home;
