import firebase from "firebase/compat/app";
import "firebase/compat/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBL2RMjup6NGpoPCg_6xDpaG1XfJtyDQg4",
  authDomain: "uas-umn.firebaseapp.com",
  projectId: "uas-umn",
  storageBucket: "uas-umn.appspot.com",
  messagingSenderId: "263665686529",
  appId: "1:263665686529:web:b52f4500bb7597c30b8800",
};

const fire = firebase.initializeApp(firebaseConfig);

export default fire;